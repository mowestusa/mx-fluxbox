# mx-fluxbox
This fluxbox version is a Window Manager designed to be used on MX Linux. It is fully integrated with Xfce4, creating an easily configurable product. 

STATUS: beta

INSTALLATION: it will eventually be available as a deb file installed via MX Package Installer. 

DEPENDENCIES: 

Any MX Linux version
idesk
